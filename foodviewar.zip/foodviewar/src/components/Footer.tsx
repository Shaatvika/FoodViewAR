import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white h-16 py-4 mt-5 inset-x-0 bottom-0 w-full">
      <div className="container mx-auto px-4">
        <p className="text-center">&copy; 2021 FoodViewAR. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;